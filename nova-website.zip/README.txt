NOVA House Hunting Website
---------------------------

Pages:
- index.html (Home)
- about.html (About Us)
- services.html (Services)
- contact.html (Contact)

How to host:
1. Upload all files to your hosting provider (public_html folder).
2. Ensure assets/ folder structure is maintained.
3. Open index.html in a browser to view the site.

Contact:
📞 0717909374
✉️ novahousehunting@gmail.com
